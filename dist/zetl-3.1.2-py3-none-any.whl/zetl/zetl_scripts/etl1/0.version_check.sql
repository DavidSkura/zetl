/*
  -- Dave Skura, 2023
*/

SELECT 'Default connection sqlite '||sqlite_version() as dbversion;
