/*
  -- Dave Skura, 2022
*/

set timezone TO 'EST';

TRUNCATE TABLE z_log;