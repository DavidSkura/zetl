/*
  -- Dave Skura, 2022
DB_TYPE		= MySQL

*/
SELECT concat('Default connection MySQL',VERSION()) as label;

SELECT count(*)
FROM CanadianPostalCodes;

