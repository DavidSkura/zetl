/*
  -- Dave Skura, 2022

*/

SELECT count(*)
FROM weather.postal_codes;

