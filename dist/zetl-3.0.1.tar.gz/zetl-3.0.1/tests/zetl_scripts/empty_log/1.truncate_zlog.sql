/*
  -- Dave Skura, 2022
*/


DELETE * FROM z_log;